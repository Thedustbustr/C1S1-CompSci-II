package Errors;

/**
 * Threads present in project
 * No multithreading so only one thread to log :(
 */
public enum Threads {
  /**
   * Main thread
   */
  main
}