package Main.Parser.Parsers;

/**
 * The ParsedData class holds all data that all parsers would need
 */
public abstract class ParsedData {
  protected String url;
}