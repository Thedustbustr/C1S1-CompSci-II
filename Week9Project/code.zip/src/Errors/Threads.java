package Errors;

/**
 * All threads in program
 */
public enum Threads {
  /**
   * Main thread
   */
  main,

  /**
  * Parser thread
  */
  waiting
}