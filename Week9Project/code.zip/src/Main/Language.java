package Main;

/**
 * Enum of languages
 */
public enum Language {
  /**
   * The java language
   */
  java,

  /**
   * The c language
   */
  c
}
