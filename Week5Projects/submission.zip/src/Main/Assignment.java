package Main;

import java.util.Calendar;
import java.util.GregorianCalendar;

import Errors.Threads;

public class Assignment {
  private String name;
  private GregorianCalendar dueDate;
  private double grade;

  /**
  * Gets name
  * @return name of assignment
  */
  public String getName() {
    return name;
  }

  /**
  * Gets due date
  * @return the due date of the assignment
  */
  public GregorianCalendar getDueDate() {
    return dueDate;
  }

  /**
  * Gets grade
  * @return double value of grade
  */
  public double getGrade() {
    return grade;
  }

  /**
  * Gets name
  * @return name of assignment
  */
  public void setName(String name) {
    this.name = name;
  }

  /**
  * Sets due date with GregorianCalendar class
  * @param dueDate the GregorianCalendar due date value
  */
  public void setDueDate(GregorianCalendar dueDate) {
    this.dueDate = dueDate;
  }

  /**
  * Sets sets due date 
  * @param year the year of the date
  * @param month the month of the date
  * @param dayOfMonth the day of the month
  * @param hourOfDay the hour of the day
  * @param minute the minute
  */
  public void setDueDate(int year, int month, int dayOfMonth, int hourOfDay, int minute) {
    this.dueDate = new GregorianCalendar(year, month, dayOfMonth, hourOfDay, minute);
  }

  /**
  * Sets grade
  * @param grade the grade to set to
  */
  public void setGrade(double grade) {
    this.grade = grade;
  }

  /**
   * Constructor
   */
  public Assignment() {
    //
  }

  /**
   * Constructor
   * @param name the name of the assignment
   * @param due the due date of the assignment
   * @param grade the grade recieved on the assignment
   */
  public Assignment(String name, GregorianCalendar due, double grade) {
    this.name = name;
    this.dueDate = due;
    this.grade = grade;
  }

  /*
   * I was trying to find a better way to do switch statements between ranges and I came across this thread: https://stackoverflow.com/questions/10873590/using-switch-statement-with-a-range-of-value-in-each-case
   * I altered someone elses code to work better in this situation.
   */
  /**
  * Gets grade letter from grade double value
  * @return grade letter
  */
  public String getGradeLetter() {
    double[] thresholds = new double[] { 0, 55, 65, 70, 78.5, 81.5, 88.5, 91.5, 96.5, 100 };
    String grade;

    int n = 0;
    for (; this.getGrade() >= (thresholds[n]); n++)
      ;
    switch (9 - n + 1) {
      case 1 -> grade = "A";
      case 2 -> grade = "A-";
      case 3 -> grade = "B+";
      case 4 -> grade = "B";
      case 5 -> grade = "B-";
      case 6 -> grade = "C+";
      case 7 -> grade = "C";
      case 8 -> grade = "D";
      case 9 -> grade = "F";
      default -> {
        Errors.Logging.Warning("Invalid grade value", Threads.main);
        return "N/A";
      }
    }

    return grade;
  }

  /**
   * Sets grade from string
   * @param grade the grade letter to get double value from
   */
  public void setGrade(String grade) {
    switch (grade) {
      case "A+" -> this.grade = 100;
      case "A" -> this.grade = 96;
      case "A-" -> this.grade = 91;
      case "B+" -> this.grade = 88;
      case "B" -> this.grade = 85;
      case "B-" -> this.grade = 81;
      case "C+" -> this.grade = 78;
      case "C" -> this.grade = 75;
      case "D" -> this.grade = 65;
      case "F" -> this.grade = 55;
      default -> Errors.Logging.Warning("Invalid grade value", Threads.main);
    }
  }

  @Override
  public String toString() {
    return "Assignment: " + this.name + "\nDue: " + dueDate.get(Calendar.HOUR_OF_DAY) + ":"
        + dueDate.get(Calendar.MINUTE) + " " + dueDate.get(Calendar.MONTH) + "/" + dueDate.get(Calendar.DATE) + "/"
        + dueDate.get(Calendar.YEAR) + "\nGrade: " + getGradeLetter() + " [" + getGrade() + "]";
  }
}
