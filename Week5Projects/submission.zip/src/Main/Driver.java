package Main;
import java.util.GregorianCalendar;

public class Driver {
  
  /** 
   * Main method
   * @param args
   */
  public static void main(String[] args) {
    Assignment assignment1 = new Assignment("Test Assignment 1", new GregorianCalendar(), 0);
    assignment1.setGrade(98.7);

    Assignment assignment2 = new Assignment();

    assignment2.setDueDate(1970, 6, 26, 23, 59);
    assignment2.setName("Test Assignment 2");
    assignment2.setGrade("B");

    System.out.println(assignment1.getName() + " Class:\n" + assignment1 + "\n====================");
    System.out.println(assignment2.getName() + " Class:\n" + assignment2 + "\n====================");

    System.out.println("Average Grade: " + (assignment1.getGrade() + assignment2.getGrade()) / 2d);
  }
}
