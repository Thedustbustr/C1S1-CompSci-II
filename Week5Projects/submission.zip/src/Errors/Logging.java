package Errors;

public final class Logging {
  public static void Log(String msg, Threads thread) {
    System.out.println("[INFO/" + thread + "] " + msg);
  }

  public static void Warning(String msg, Threads thread, Exception... e) {
    System.out.println("[WARN/" + thread + "] " + msg + "\n" + e);
  }

  public static void Error(String msg, Threads thread, Exception e) {
    System.out.println("[FATAL/" + thread + "] " + msg + "\n" + e);
  }
}
