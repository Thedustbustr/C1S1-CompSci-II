package Errors;

/*
 * No multithreading so only one thread to log :(
 */
public enum Threads {
  main
}